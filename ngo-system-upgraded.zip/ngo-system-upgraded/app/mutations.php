<?php
function mutate():string {
 global $pdo;
 $action=$_POST['action']??'';
 if($action==='logout'){$_SESSION=[];session_regenerate_id(true);return 'login.php';}
 if($action==='beneficiary'){
 operational();$id=(int)($_POST['id']??0);$editing=$id>0;if($id)benefRow($id);
 $first=required('first_name',50);$last=required('last_name',50);$dob=day('date_of_birth');if($dob>date('Y-m-d'))throw new RuntimeException('Birth date cannot be in the future.');
 $phone=trim((string)($_POST['contact_info']??''));if(strlen($phone)>100)throw new RuntimeException('Contact is too long.');
 $exact=q('SELECT beneficiary_id FROM beneficiaries WHERE LOWER(TRIM(first_name))=LOWER(?) AND LOWER(TRIM(last_name))=LOWER(?) AND date_of_birth=? AND beneficiary_id<>? LIMIT 1',[$first,$last,$dob,$id])->fetchColumn();
 $possible=q("SELECT beneficiary_id FROM beneficiaries WHERE beneficiary_id<>? AND ((LOWER(TRIM(first_name))=LOWER(?) AND LOWER(TRIM(last_name))=LOWER(?)) OR (?<>'' AND contact_info=?)) LIMIT 1",[$id,$first,$last,$phone,$phone])->fetchColumn();
 if($exact)throw new RuntimeException('Duplicate warning: a record with the same name and birth date already exists. Ask a supervisor to review the existing record.');
 if($possible&&empty($_POST['duplicate_ack']))throw new RuntimeException('Possible duplicate: the name or contact matches an existing record. Check the duplicate acknowledgement only after reviewing with a supervisor.');
 $a=[$first,$last,$dob,option('sex',['Male','Female','Other']),$phone,required('location',150),day('registration_date')];
 if($id)q('UPDATE beneficiaries SET first_name=?,last_name=?,date_of_birth=?,sex=?,contact_info=?,location=?,registration_date=? WHERE beneficiary_id=?',[...$a,$id]);
 else{q('INSERT INTO beneficiaries(first_name,last_name,date_of_birth,sex,contact_info,location,registration_date,registered_by) VALUES(?,?,?,?,?,?,?,?)',[...$a,uid()]);$id=(int)$pdo->lastInsertId();}
 audit($editing?'edit':'create','beneficiary',$id,$possible?'Possible duplicate acknowledged':'');return 'beneficiaries.php';
 }
 if($action==='create_case'){
 operational();$bid=(int)($_POST['beneficiary_id']??0);benefRow($bid);$wid=role()==='CaseWorker'?uid():(int)($_POST['assigned_worker_id']??0);worker($wid);
 q("INSERT INTO cases(beneficiary_id,case_type,priority,assigned_worker_id,date_opened,case_status) VALUES(?,?,?,?,?,'Open')",[$bid,required('case_type',100),option('priority',['Low','Medium','High','Urgent']),$wid,day('date_opened')]);$id=(int)$pdo->lastInsertId();event($id,'Opened','Case opened and assigned to worker #'.$wid);audit('create','case',$id);return 'case_details.php?id='.$id;
 }
 if(in_array($action,['assessment','intervention','referral','followup','resolve_referral','resolve_followup','assign','request_close','review_close','upload','referral_due'],true)){
 $id=(int)($_POST['case_id']??0);$c=writableCase($id);if($c['closure_requested_at']&&$action!=='review_close')throw new RuntimeException('This case is awaiting supervisor closure review. Reject the request before making further changes.');
 if($action==='assessment'){
 q('INSERT INTO assessments(case_id,assessed_by,assessment_date,identified_needs,risk_level,observations,recommendations) VALUES(?,?,?,?,?,?,?)',[$id,uid(),day('assessment_date'),required('identified_needs'),option('risk_level',['Low','Moderate','High','Severe']),trim($_POST['observations']??''),trim($_POST['recommendations']??'')]);audit('create assessment','case',$id);
 }elseif($action==='intervention'){
 q('INSERT INTO interventions(case_id,service_type,description,service_provider,intervention_date,outcome) VALUES(?,?,?,?,?,?)',[$id,required('service_type',100),required('description'),required('service_provider',150),day('intervention_date'),required('outcome')]);audit('create intervention','case',$id);
 }elseif($action==='referral'){
 $date=day('referral_date');$due=day('due_date');if($due<$date)throw new RuntimeException('Referral due date must not precede the referral date.');
 q('INSERT INTO referrals(case_id,referred_to_organization,service_required,referral_date,due_date) VALUES(?,?,?,?,?)',[$id,required('referred_to_organization',150),required('service_required',150),$date,$due]);audit('create referral','case',$id);
 }elseif($action==='referral_due'){
 $rid=(int)($_POST['referral_id']??0);$due=day('due_date');$r=q("SELECT * FROM referrals WHERE referral_id=? AND case_id=? AND referral_status='Pending'",[$rid,$id])->fetch();if(!$r||$due<$r['referral_date'])throw new RuntimeException('Choose a pending referral and a due date on or after its referral date.');q('UPDATE referrals SET due_date=? WHERE referral_id=?',[$due,$rid]);event($id,'Referral due date updated','Referral #'.$rid.' due '.$due);audit('update due date','referral',$rid);
 }elseif($action==='followup'){
 q('INSERT INTO follow_ups(case_id,next_follow_up_date,notes) VALUES(?,?,?)',[$id,day('next_follow_up_date'),required('notes')]);audit('schedule follow-up','case',$id);
 }elseif($action==='resolve_referral'){
 $rid=(int)($_POST['referral_id']??0);$status=option('referral_status',['Completed','Cancelled']);$out=required('completion_info');
 $s=q("UPDATE referrals SET referral_status=?,completion_info=? WHERE referral_id=? AND case_id=? AND referral_status='Pending'",[$status,$out,$rid,$id]);if(!$s->rowCount())throw new RuntimeException('Pending referral unavailable.');event($id,'Referral '.$status,'Referral #'.$rid.': '.$out);audit('resolve referral','referral',$rid);
 }elseif($action==='resolve_followup'){
 $fid=(int)($_POST['follow_up_id']??0);$out=required('outcome');$s=q("UPDATE follow_ups SET status='Completed',outcome=? WHERE follow_up_id=? AND case_id=? AND status IN ('Scheduled','Missed')",[$out,$fid,$id]);if(!$s->rowCount())throw new RuntimeException('Pending follow-up unavailable.');event($id,'Follow-up completed','Follow-up #'.$fid.': '.$out);audit('resolve follow-up','follow_up',$fid);
 }elseif($action==='assign'){
 need(['Supervisor','Admin']);$wid=(int)($_POST['assigned_worker_id']??0);worker($wid);q('UPDATE cases SET assigned_worker_id=? WHERE case_id=?',[$wid,$id]);event($id,'Assignment','Reassigned from worker #'.$c['assigned_worker_id'].' to worker #'.$wid);audit('assign','case',$id);
 }elseif($action==='request_close'){
 if($c['closure_requested_at'])throw new RuntimeException('A closure request is already awaiting review.');if(pending($id))throw new RuntimeException('Resolve pending referrals and follow-ups before requesting closure.');
 $out=required('closure_outcome');q('UPDATE cases SET closure_outcome=?,closure_requested_by=?,closure_requested_at=NOW(),closure_review=NULL WHERE case_id=?',[$out,uid(),$id]);event($id,'Closure requested',$out);audit('request closure','case',$id);
 }elseif($action==='review_close'){
 need(['Supervisor']);if(!$c['closure_requested_at'])throw new RuntimeException('No closure request is pending.');if((int)$c['closure_requested_by']===uid())throw new RuntimeException('Another supervisor must review your closure request.');
 $review=required('closure_review');$decision=option('decision',['Approve','Reject']);
 if($decision==='Approve'){if(pending($id))throw new RuntimeException('Resolve pending activities before closure.');q("UPDATE cases SET case_status='Closed',closed_by=?,closed_at=NOW(),closure_review=? WHERE case_id=?",[uid(),$review,$id]);}
 else q('UPDATE cases SET closure_requested_at=NULL,closure_requested_by=NULL,closure_review=? WHERE case_id=?',[$review,$id]);event($id,'Closure '.$decision,$review);audit('closure '.$decision,'case',$id);
 }else{
 $f=$_FILES['document']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK)throw new RuntimeException('Choose a file up to 10 MB.');if($f['size']<1||$f['size']>10*1024*1024||!is_uploaded_file($f['tmp_name']))throw new RuntimeException('Invalid upload or file exceeds 10 MB.');
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$types=['application/pdf'=>'pdf','image/png'=>'png','image/jpeg'=>'jpg'];if(!isset($types[$mime]))throw new RuntimeException('Only PDF, PNG and JPEG documents are accepted.');
 $name=basename(str_replace('\\','/',$f['name']));if(mb_strlen($name)>180||preg_match('/[\x00-\x1f]/',$name))throw new RuntimeException('Invalid filename.');$stored=bin2hex(random_bytes(24)).'.'.$types[$mime];$desc=required('description',250);$sha=hash_file('sha256',$f['tmp_name']);
 if(!move_uploaded_file($f['tmp_name'],STORE.'/documents/'.$stored))throw new RuntimeException('Unable to store document.');$GLOBALS['new_upload']=STORE.'/documents/'.$stored;
 q('INSERT INTO documents(case_id,original_name,stored_name,mime,size_bytes,sha256,description,uploaded_by) VALUES(?,?,?,?,?,?,?,?)',[$id,$name,$stored,$mime,$f['size'],$sha,$desc,uid()]);event($id,'Document attached',$desc.' ('.$name.')');audit('upload','case',$id);
 }
 return 'case_details.php?id='.$id;
 }
 if($action==='create_user'){
 need(['Admin']);$email=required('email',100);if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Invalid email.');q('INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)',[required('username',50),$email,password_hash(passwordInput(),PASSWORD_DEFAULT),option('role',['Admin','Supervisor','Management','CaseWorker'])]);audit('create','user',(int)$pdo->lastInsertId());return 'users_admin.php';
 }
 if($action==='toggle_user'){
 need(['Admin']);$id=(int)($_POST['user_id']??0);if($id===uid())throw new RuntimeException('You cannot deactivate yourself.');if(q("SELECT case_id FROM cases WHERE assigned_worker_id=? AND case_status<>'Closed' LIMIT 1",[$id])->fetch())throw new RuntimeException('Reassign active cases first.');q('UPDATE users SET active=1-active,session_version=session_version+1 WHERE user_id=?',[$id]);audit('toggle access','user',$id);return 'users_admin.php';
 }
 if($action==='issue_reset'){
 need(['Admin']);if(!password_verify($_POST['admin_password']??'',q('SELECT password_hash FROM users WHERE user_id=?',[uid()])->fetchColumn()))throw new RuntimeException('Confirm your administrator password.');if(empty($_POST['verified_identity']))throw new RuntimeException('Verify the staff member’s identity before issuing a recovery link.');$id=(int)($_POST['user_id']??0);if(!q('SELECT user_id FROM users WHERE user_id=? AND active=1',[$id])->fetch())throw new RuntimeException('Active account unavailable.');
 q('UPDATE password_resets SET used_at=NOW() WHERE user_id=? AND used_at IS NULL',[$id]);$raw=bin2hex(random_bytes(32));q('INSERT INTO password_resets(user_id,token_hash,expires_at,created_by) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 30 MINUTE),?)',[$id,hash('sha256',$raw),uid()]);q('UPDATE recovery_requests SET resolved_at=NOW() WHERE user_id=? AND resolved_at IS NULL',[$id]);$_SESSION['reset_link']='reset_password.php?token='.$raw;audit('issue recovery link','user',$id);return 'users_admin.php';
 }
 throw new RuntimeException('Unknown action.');
}
