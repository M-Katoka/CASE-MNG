<?php
function exportXlsx(array $rows):string{
 $path=tempnam(STORE,'xlsx');$z=new ZipArchive();$z->open($path,ZipArchive::OVERWRITE);
 $z->addFromString('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
 $z->addFromString('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
 $z->addFromString('xl/workbook.xml','<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Case report" sheetId="1" r:id="rId1"/></sheets></workbook>');
 $z->addFromString('xl/_rels/workbook.xml.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
 $xml='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols><col min="1" max="12" width="24" customWidth="1"/></cols><sheetData>';
 foreach($rows as $i=>$row){$xml.='<row r="'.($i+1).'">';foreach($row as $j=>$val){$cell=chr(65+$j).($i+1);$v=preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u','',(string)$val);$xml.='<c r="'.$cell.'" t="inlineStr"><is><t xml:space="preserve">'.htmlspecialchars($v,ENT_XML1|ENT_QUOTES,'UTF-8').'</t></is></c>';}$xml.='</row>';}$xml.='</sheetData></worksheet>';$z->addFromString('xl/worksheets/sheet1.xml',$xml);$z->close();return $path;
}
function exportPdf(array $rows,string $caption):string{
 // Portable text PDF, with wrapped record fields and complete pagination.
 $lines=['NGO Case Management Report',$caption,'Generated '.date('d M Y H:i'),''];$headers=array_shift($rows);
 foreach($rows as $i=>$row){$lines[]='Record '.($i+1);foreach($row as $j=>$v){$text=$headers[$j].': '.(string)$v;foreach(explode("\n",wordwrap($text,100,"\n",true)) as $line)$lines[]=$line;}$lines[]='';}
 if(!$rows)$lines[]='No records match these filters.';
 $pages=array_chunk($lines,48);$obj=[1=>'<< /Type /Catalog /Pages 2 0 R >>',3=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'];$kids=[];
 foreach($pages as $i=>$lines){$pid=4+$i*2;$cid=$pid+1;$kids[]="$pid 0 R";$stream="BT /F1 10 Tf 48 790 Td 15 TL ";foreach($lines as $line){$latin=iconv('UTF-8','Windows-1252//TRANSLIT//IGNORE',$line);$safe=str_replace(['\\','(',')',"\r"],['\\\\','\\(','\\)',''],$latin);$stream.="($safe) Tj T*\n";}$stream.="ET\nBT /F1 9 Tf 48 25 Td (Page ".($i+1).' of '.count($pages).") Tj ET";
 $obj[$pid]="<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents $cid 0 R >>";$obj[$cid]='<< /Length '.strlen($stream).">>\nstream\n".$stream."\nendstream";}
 $obj[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($pages).' >>';ksort($obj);$pdf="%PDF-1.4\n";$offset=[0];foreach($obj as $id=>$o){$offset[$id]=strlen($pdf);$pdf.="$id 0 obj\n$o\nendobj\n";}$xref=strlen($pdf);$pdf.='xref'."\n0 ".(count($obj)+1)."\n0000000000 65535 f \n";foreach($obj as $id=>$o)$pdf.=sprintf("%010d 00000 n \n",$offset[$id]);$pdf.='trailer << /Size '.(count($obj)+1).' /Root 1 0 R >>'."\nstartxref\n$xref\n%%EOF";return $pdf;
}
function reportData():array{
 [$w,$a]=reportFilter();if(role()==='Management'){$r=q("SELECT c.case_type,c.case_status,c.priority,COUNT(*) total FROM cases c WHERE $w GROUP BY c.case_type,c.case_status,c.priority ORDER BY c.case_type,c.case_status",$a)->fetchAll(PDO::FETCH_NUM);return [['Programme','Status','Priority','Cases'],...$r];}
 $r=q("SELECT c.case_id,CONCAT(b.first_name,' ',b.last_name),c.case_type,c.priority,c.case_status,c.date_opened,COALESCE(u.username,'Unassigned') FROM cases c JOIN beneficiaries b ON b.beneficiary_id=c.beneficiary_id LEFT JOIN users u ON u.user_id=c.assigned_worker_id WHERE $w ORDER BY c.date_opened DESC,c.case_id DESC",$a)->fetchAll(PDO::FETCH_NUM);return [['Case ID','Beneficiary','Programme','Priority','Status','Opened','Worker'],...$r];
}
