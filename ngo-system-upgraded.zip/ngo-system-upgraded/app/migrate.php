<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/core.php';
function column(string $table,string $col,string $def):void{if(!q('SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?',[$table,$col])->fetch())q("ALTER TABLE `$table` ADD `$col` $def");}
column('users','active','BOOLEAN NOT NULL DEFAULT 1');column('users','session_version','INT NOT NULL DEFAULT 1');
column('cases','closure_outcome','TEXT NULL');column('cases','closure_requested_by','INT NULL');column('cases','closure_requested_at','DATETIME NULL');column('cases','closed_by','INT NULL');column('cases','closed_at','DATETIME NULL');column('cases','closure_review','TEXT NULL');
column('referrals','due_date','DATE NULL');column('follow_ups','outcome','TEXT NULL');
foreach([
"CREATE TABLE IF NOT EXISTS audit_log(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL,action VARCHAR(80) NOT NULL,record_type VARCHAR(40) NOT NULL,record_id INT NOT NULL DEFAULT 0,details TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(created_at),INDEX(record_type,record_id)) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS case_events(id INT AUTO_INCREMENT PRIMARY KEY,case_id INT NOT NULL,kind VARCHAR(60) NOT NULL,details TEXT NOT NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(case_id) REFERENCES cases(case_id),INDEX(case_id,created_at)) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS documents(id INT AUTO_INCREMENT PRIMARY KEY,case_id INT NOT NULL,original_name VARCHAR(180) NOT NULL,stored_name VARCHAR(100) NOT NULL,mime VARCHAR(100) NOT NULL,size_bytes INT NOT NULL,sha256 CHAR(64) NOT NULL,description VARCHAR(250) NOT NULL,uploaded_by INT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(case_id) REFERENCES cases(case_id)) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS password_resets(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,token_hash CHAR(64) UNIQUE NOT NULL,expires_at DATETIME NOT NULL,used_at DATETIME NULL,created_by INT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(user_id)) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS recovery_requests(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,resolved_at DATETIME NULL,FOREIGN KEY(user_id) REFERENCES users(user_id)) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS auth_attempts(key_hash CHAR(64) PRIMARY KEY,attempts INT NOT NULL,last_at DATETIME NOT NULL) ENGINE=InnoDB"
] as $sql)q($sql);
echo "Migration complete. Existing records retained.\n";
