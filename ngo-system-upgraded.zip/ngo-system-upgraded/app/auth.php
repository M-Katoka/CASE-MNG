<?php
require_once __DIR__.'/core.php';
$mode=basename($_SERVER['SCRIPT_NAME']);$error='';$notice='';
if($mode==='login.php'&&currentUser())go('dashboard.php');
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
 if(!is_string($_POST['csrf']??null)||!hash_equals(token(),$_POST['csrf']))throw new RuntimeException('Form expired. Reload and try again.');
 $key=hash('sha256',($_SERVER['REMOTE_ADDR']??'').'|'.$mode.'|'.strtolower(trim($_POST['username']??'')));$a=q('SELECT * FROM auth_attempts WHERE key_hash=?',[$key])->fetch();if($a&&(int)$a['attempts']>=8&&strtotime($a['last_at'])>time()-900)throw new RuntimeException('Too many attempts. Try again in 15 minutes.');
 q('INSERT INTO auth_attempts(key_hash,attempts,last_at) VALUES(?,1,NOW()) ON DUPLICATE KEY UPDATE attempts=IF(last_at<DATE_SUB(NOW(),INTERVAL 15 MINUTE),1,attempts+1),last_at=NOW()',[$key]);
 if($mode==='login.php'){
 $name=required('username',255);$u=q('SELECT * FROM users WHERE (username=? OR email=?) AND active=1',[$name,$name])->fetch();
 if(!$u||!password_verify($_POST['password']??'',$u['password_hash']))throw new RuntimeException('Invalid username or password.');
 session_regenerate_id(true);$_SESSION=['user_id'=>$u['user_id'],'username'=>$u['username'],'role'=>$u['role'],'version'=>$u['session_version'],'last'=>time()];q('DELETE FROM auth_attempts WHERE key_hash=?',[$key]);audit('login','user',uid());go('dashboard.php');
 }elseif($mode==='forgot_password.php'){
 $name=required('username',255);$u=q('SELECT user_id FROM users WHERE (username=? OR email=?) AND active=1',[$name,$name])->fetchColumn();if($u&&!q('SELECT id FROM recovery_requests WHERE user_id=? AND resolved_at IS NULL',[$u])->fetch()){q('INSERT INTO recovery_requests(user_id) VALUES(?)',[$u]);}
 $notice='If the account exists, a recovery request has been recorded. Contact your administrator for identity verification and a private recovery link.';
 }else{
 $password=passwordInput();if($password!==($_POST['confirm_password']??''))throw new RuntimeException('Passwords do not match.');$raw=(string)($_POST['token']??'');
 lockWrites();try{$pdo->beginTransaction();$r=q('SELECT * FROM password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW() FOR UPDATE',[hash('sha256',$raw)])->fetch();if(!$r||!q('SELECT user_id FROM users WHERE user_id=? AND active=1',[$r['user_id']])->fetch())throw new RuntimeException('Recovery link is invalid or expired.');
 q('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE user_id=?',[password_hash($password,PASSWORD_DEFAULT),$r['user_id']]);q('UPDATE password_resets SET used_at=NOW() WHERE user_id=? AND used_at IS NULL',[$r['user_id']]);audit('password recovered','user',(int)$r['user_id']);$pdo->commit();$_SESSION=[];$notice='Password updated. Sign in with your new password.';}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}finally{unlockWrites();}
 }
 }catch(Throwable $e){$error=$e instanceof PDOException?'Unable to process this request.':$e->getMessage();}
}
$title=$mode==='login.php'?'Sign in':($mode==='forgot_password.php'?'Request password recovery':'Set a new password');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=esc($title)?> | NGO Portal</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"><link rel="stylesheet" href="assets/portal.css"></head><body><main class="auth card"><h1><?=esc($title)?></h1><p class="text-muted">NGO Case Management Information System</p><?php if($error):?><p class="alert alert-danger"><?=esc($error)?></p><?php endif;?><?php if($notice):?><p class="alert alert-info"><?=esc($notice)?></p><?php endif;?>
<form method="post"><?=csrf()?><?php if($mode!=='reset_password.php'):?><label>Username or email<input class="form-control" name="username" required autocomplete="username"></label><?php else:?><input type="hidden" name="token" value="<?=esc($_POST['token']??$_GET['token']??'')?>"><?php endif;?>
<?php if($mode!=='forgot_password.php'):?><label>Password<input class="form-control" type="password" name="password" required autocomplete="<?=$mode==='login.php'?'current-password':'new-password'?>" <?=$mode==='login.php'?'':'minlength="12" maxlength="72"'?>></label><?php endif;?>
<?php if($mode==='reset_password.php'):?><label>Confirm password<input class="form-control" type="password" name="confirm_password" required autocomplete="new-password"></label><?php endif;?>
<button class="btn btn-primary mt-3"><?=esc($title)?></button></form><p class="mt-3"><a href="login.php">Sign in</a> · <a href="forgot_password.php">Forgot password?</a></p><p class="text-muted small">Accounts are provisioned by your administrator.</p></main></body></html>
