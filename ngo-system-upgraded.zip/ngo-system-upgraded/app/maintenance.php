<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/core.php';require __DIR__.'/archive.php';
$cmd=$argv[1]??'';
if($cmd==='backup'){echo makeBackup().PHP_EOL;exit;}
if($cmd==='restore'&&($argv[3]??'')==='--confirm-replace'){echo 'Safety backup: '.makeBackup().PHP_EOL;restoreBackup($argv[2]);echo "Recovery complete.\n";exit;}
echo "Usage: php app/maintenance.php backup\n       php app/maintenance.php restore PATH --confirm-replace\n";
