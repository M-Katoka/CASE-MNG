<?php
const BACKUP_TABLES=['users','beneficiaries','cases','assessments','interventions','referrals','follow_ups','audit_log','case_events','documents','password_resets','recovery_requests','auth_attempts'];
function makeBackup():string{
 global $pdo;
 lockWrites();$path=STORE.'/backups/ngo-'.date('Ymd-His').'-'.bin2hex(random_bytes(4)).'.zip';
 try{
 $pdo->beginTransaction();$tables=[];foreach(BACKUP_TABLES as $t)$tables[$t]=q("SELECT * FROM `$t`")->fetchAll();
 $z=new ZipArchive();if($z->open($path,ZipArchive::CREATE|ZipArchive::EXCL)!==true)throw new RuntimeException('Could not create backup.');
 $z->addFromString('manifest.json',json_encode(['format'=>'ngo-v2','version'=>1,'created'=>date(DATE_ATOM),'tables'=>$tables],JSON_THROW_ON_ERROR));
 foreach($tables['documents'] as $d){$file=STORE.'/documents/'.$d['stored_name'];if(!is_file($file)||hash_file('sha256',$file)!==$d['sha256'])throw new RuntimeException('Document integrity check failed; backup cancelled.');$z->addFile($file,'documents/'.$d['stored_name']);}
 if(!$z->close())throw new RuntimeException('Could not finish backup.');$pdo->commit();return $path;
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();if(is_file($path))unlink($path);throw $e;}finally{unlockWrites();}
}
function restoreBackup(string $path):void{
 global $pdo;
 if(!is_file($path)||filesize($path)>250*1024*1024)throw new RuntimeException('Backup is missing or exceeds 250 MB.');
 $z=new ZipArchive();if($z->open($path)!==true)throw new RuntimeException('Invalid backup ZIP.');$total=0;for($i=0;$i<$z->numFiles;$i++){$st=$z->statIndex($i);$total+=$st['size'];if($total>500*1024*1024)throw new RuntimeException('Expanded archive is too large.');}
 $raw=$z->getFromName('manifest.json');if(!$raw||strlen($raw)>100*1024*1024)throw new RuntimeException('Invalid manifest.');$m=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
 if(($m['format']??'')!=='ngo-v2'||($m['version']??0)!==1||array_keys($m['tables']??[])!==BACKUP_TABLES)throw new RuntimeException('Unsupported backup format.');
 foreach(BACKUP_TABLES as $t){$cols=array_column(q("SHOW COLUMNS FROM `$t`")->fetchAll(),'Field');foreach($m['tables'][$t] as $r){if(array_keys($r)!==$cols)throw new RuntimeException('Backup schema mismatch: '.$t);}}
 $newFiles=[];lockWrites();
 try{
 foreach($m['tables']['documents'] as &$d){if(!preg_match('/^[a-f0-9]{48}\.(pdf|png|jpg)$/',$d['stored_name']))throw new RuntimeException('Invalid document path.');$data=$z->getFromName('documents/'.$d['stored_name']);if($data===false||strlen($data)!==(int)$d['size_bytes']||hash('sha256',$data)!==$d['sha256'])throw new RuntimeException('Backup document checksum mismatch.');$d['stored_name']=bin2hex(random_bytes(24)).'.'.pathinfo($d['stored_name'],PATHINFO_EXTENSION);$file=STORE.'/documents/'.$d['stored_name'];if(file_put_contents($file,$data)!==strlen($data))throw new RuntimeException('Document restore failed.');$newFiles[]=$file;}unset($d);
 $pdo->beginTransaction();foreach(array_reverse(BACKUP_TABLES) as $t)q("DELETE FROM `$t`");
 foreach(BACKUP_TABLES as $t){foreach($m['tables'][$t] as $r){$cols='`'.implode('`,`',array_keys($r)).'`';q("INSERT INTO `$t` ($cols) VALUES(".implode(',',array_fill(0,count($r),'?')).')',array_values($r));}}
 q('UPDATE users SET session_version=session_version+1');q('UPDATE password_resets SET used_at=NOW() WHERE used_at IS NULL');q('DELETE FROM auth_attempts');audit('restore completed','system');$pdo->commit();
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();foreach($newFiles as $f)if(is_file($f))unlink($f);throw $e;}finally{$z->close();unlockWrites();}
}
