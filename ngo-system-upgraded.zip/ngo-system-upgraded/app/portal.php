<?php
require_once __DIR__.'/core.php';require_once __DIR__.'/exports.php';require_once __DIR__.'/archive.php';require_once __DIR__.'/mutations.php';
$u=currentUser();if(!$u)go('login.php');$page=basename($_SERVER['SCRIPT_NAME']);$error='';
$routes=['dashboard.php','beneficiaries.php','cases.php','case_details.php','referrals.php','follow_ups.php','reports.php','users_admin.php','audit.php','backups.php','documents.php','export.php','search.php','supervisor_workload.php','logout.php'];
try{
 if(!in_array($page,$routes,true))throw new RuntimeException('Page not found.',404);
 if(in_array($page,['users_admin.php','backups.php'],true))need(['Admin']);
 if($page==='audit.php')need(['Admin','Supervisor']);
 if(in_array($page,['beneficiaries.php','cases.php','case_details.php','referrals.php','follow_ups.php','documents.php','search.php'],true))operational();
 if($page==='case_details.php')caseRow((int)($_GET['id']??0));
 if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!is_string($_POST['csrf']??null)||!hash_equals(token(),$_POST['csrf']))throw new RuntimeException('Invalid or expired form. Reload and try again.',403);
 if(($_POST['action']??'')==='backup'){
 need(['Admin']);$path=makeBackup();audit('create backup','system',0,basename($path));go('backups.php','Backup created, including supporting documents.');
 }elseif(($_POST['action']??'')==='restore'){
 need(['Admin']);if(!password_verify($_POST['admin_password']??'',$u['password_hash'])||($_POST['confirmation']??'')!=='RESTORE')throw new RuntimeException('Enter your password and type RESTORE to confirm.');
 $name=basename((string)($_POST['backup_name']??''));if(!preg_match('/^ngo-[a-zA-Z0-9-]+\.zip$/',$name))throw new RuntimeException('Choose an existing backup.');$path=STORE.'/backups/'.$name;if(!is_file($path))throw new RuntimeException('Backup unavailable.');
 $safety=makeBackup();restoreBackup($path);$_SESSION=[];go('login.php');
 }else{
 lockWrites();$new_upload=null;
 try{$pdo->beginTransaction();$to=mutate();$pdo->commit();}catch(Throwable $ex){if($pdo->inTransaction())$pdo->rollBack();if($new_upload&&is_file($new_upload))unlink($new_upload);throw $ex;}finally{unlockWrites();}
 go($to,'Saved successfully.');
 }
 }
 if($page==='documents.php'){
 $d=q('SELECT * FROM documents WHERE id=?',[(int)($_GET['id']??0)])->fetch();if(!$d)throw new RuntimeException('Document unavailable.',404);caseRow((int)$d['case_id']);$file=STORE.'/documents/'.$d['stored_name'];if(!is_file($file)||hash_file('sha256',$file)!==$d['sha256'])throw new RuntimeException('Document integrity check failed.');audit('download','document',(int)$d['id']);header('Content-Type: '.$d['mime']);header("Content-Disposition: attachment; filename*=UTF-8''".rawurlencode($d['original_name']));header('Content-Length: '.filesize($file));readfile($file);exit;
 }
 if($page==='export.php'){
 $rows=reportData();$format=$_GET['format']??'';audit('export '.$format,'report');if($format==='xlsx'){$f=exportXlsx($rows);header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="case-report.xlsx"');readfile($f);unlink($f);exit;}
 if($format==='pdf'){$caption='Opened: '.($_GET['from']??'').' to '.($_GET['to']??'').' | Programme: '.($_GET['programme']??'All').' | Worker: '.($_GET['worker']??'All').' | Status: '.($_GET['status']??'All');header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="case-report.pdf"');echo exportPdf($rows,$caption);exit;}throw new RuntimeException('Unknown export format.');
 }
 if($page==='backups.php'&&isset($_GET['download'])){$name=basename((string)$_GET['download']);if(!preg_match('/^ngo-[a-zA-Z0-9-]+\.zip$/',$name)||!is_file(STORE.'/backups/'.$name))throw new RuntimeException('Backup unavailable.',404);audit('download backup','system',0,$name);header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.$name.'"');readfile(STORE.'/backups/'.$name);exit;}
}catch(Throwable $ex){$code=in_array($ex->getCode(),[403,404],true)?$ex->getCode():400;http_response_code($code);$error=$ex instanceof PDOException?'The record could not be saved. Check for duplicate account details or invalid references.':$ex->getMessage();if($code===403||$code===404){echo '<h1>'.esc($error).'</h1><a href="dashboard.php">Return to overview</a>';exit;}}
function field(string $name,string $label,string $type='text',$value='',bool $req=true):void{echo '<label>'.esc($label).'<input class="form-control" type="'.esc($type).'" name="'.esc($name).'" value="'.esc($value).'" '.($req?'required':'').'></label>';}
function select(string $name,string $label,array $options,$value=''):void{echo '<label>'.esc($label).'<select class="form-select" name="'.esc($name).'">';foreach($options as $k=>$v)echo '<option value="'.esc($k).'" '.((string)$k===(string)$value?'selected':'').'>'.esc($v).'</option>';echo '</select></label>';}
function opts(array $a):array{return array_combine($a,$a);}
function hidden(string $n,$v):void{echo '<input type="hidden" name="'.esc($n).'" value="'.esc($v).'">';}
function form(string $a,array $hidden=[],bool $file=false):void{echo '<form method="post" class="grid" '.($file?'enctype="multipart/form-data"':'').'>'.csrf();hidden('action',$a);foreach($hidden as $k=>$v)hidden($k,$v);}
function endform(string $label='Save'):void{echo '<div class="wide"><button class="btn btn-primary">'.esc($label).'</button></div></form>';}
function area(string $n,string $label,bool $req=true):void{echo '<label class="wide">'.esc($label).'<textarea class="form-control" name="'.esc($n).'" rows="3" maxlength="5000" '.($req?'required':'').'></textarea></label>';}
function section(string $title):void{echo '<section class="card"><h2>'.esc($title).'</h2>';}
function endsection():void{echo '</section>';}
function table(array $heads,array $rows):void{echo '<div class="table-responsive"><table class="table"><thead><tr>';foreach($heads as $h)echo '<th>'.esc($h).'</th>';echo '</tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="'.count($heads).'">No matching records.</td></tr>';foreach($rows as $r){echo '<tr>';foreach($r as $v)echo '<td>'.$v.'</td>';echo '</tr>';}echo '</tbody></table></div>';}
function workersOptions():array{return array_column(workers(),'username','user_id');}
function caseLink($id):string{return '<a href="case_details.php?id='.(int)$id.'">Case #'.(int)$id.'</a>';}
function filters():void{echo '<form class="grid" method="get">';field('from','Opened from','date',$_GET['from']??'',false);field('to','Opened to','date',$_GET['to']??'',false);[$w,$a]=scope();$names=q("SELECT DISTINCT c.case_type FROM cases c WHERE $w ORDER BY c.case_type",$a)->fetchAll(PDO::FETCH_COLUMN);select('programme','Programme',[''=>'All programmes']+opts($names),$_GET['programme']??'');$workers=role()==='CaseWorker'?[uid()=>$_SESSION['username']]:workersOptions();select('worker','Assigned worker',[''=>'All permitted workers']+$workers,$_GET['worker']??'');select('status','Status',[''=>'All statuses']+opts(['Open','Under Review','Escalated','Closed']),$_GET['status']??'');echo '<div class="wide"><button class="btn btn-primary">Apply filters</button></div></form>';}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NGO Portal</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"><link rel="stylesheet" href="assets/professional.css"><link rel="stylesheet" href="assets/portal.css"></head><body>
<header class="top"><a href="dashboard.php">NGO Portal</a><span><?=esc($_SESSION['username'])?> · <?=esc(role())?></span></header><nav>
<?php $links=['dashboard.php'=>'Overview'];if(role()!=='Management')$links+=['beneficiaries.php'=>'Beneficiaries','cases.php'=>'Cases','referrals.php'=>'Referrals','follow_ups.php'=>'Reminders'];$links+=['reports.php'=>'Reports'];if(in_array(role(),['Supervisor','Admin'],true))$links+=['audit.php'=>'Audit log'];if(role()==='Admin')$links+=['users_admin.php'=>'Team accounts','backups.php'=>'Backup & recovery'];foreach($links as $url=>$label)echo '<a '.($page===$url?'class="active"':'').' href="'.$url.'">'.esc($label).'</a>'; ?>
<form method="post"><?=csrf()?><?php hidden('action','logout');?><button class="btn btn-sm btn-outline-secondary">Sign out</button></form></nav><main>
<?php if($error)echo '<p role="alert" class="alert alert-danger">'.esc($error).'</p>';if(isset($_SESSION['message'])){echo '<p role="status" class="alert alert-success">'.esc($_SESSION['message']).'</p>';unset($_SESSION['message']);}
try{require __DIR__.'/views.php';}catch(Throwable $e){echo '<p class="alert alert-danger">'.esc($e instanceof PDOException?'Unable to load records.':$e->getMessage()).'</p>';}
?></main><footer>NGO Case Management Information System · Authorised staff access</footer></body></html>
