<?php
declare(strict_types=1);
const ROOT = __DIR__.'/..';
date_default_timezone_set('Africa/Lusaka');
if(session_status()!==PHP_SESSION_ACTIVE){session_name('NGOV2SESSION');ini_set('session.use_strict_mode','1');session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);session_start();}
header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');header('X-Frame-Options: DENY');header('Referrer-Policy: no-referrer');
require_once ROOT.'/db.php';
$pdo->exec("SET time_zone = '+02:00'");
define('STORE',getenv('NGO_STORAGE')?:dirname(realpath(ROOT),2).'/work/ngo-v2-private');
foreach(['','/documents','/backups'] as $d)if(!is_dir(STORE.$d))mkdir(STORE.$d,0700,true);
function q(string $sql,array $args=[]): PDOStatement {global $pdo;$s=$pdo->prepare($sql);$s->execute($args);return $s;}
function esc($s):string{return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function uid():int{return (int)($_SESSION['user_id']??0);}
function role():string{return (string)($_SESSION['role']??'');}
function token():string{return $_SESSION['csrf']??=bin2hex(random_bytes(32));}
function csrf():string{return '<input type="hidden" name="csrf" value="'.esc(token()).'">';}
function audit(string $action,string $type,int $id=0,string $detail=''):void{q('INSERT INTO audit_log(user_id,action,record_type,record_id,details) VALUES(?,?,?,?,?)',[uid()?:null,$action,$type,$id,$detail]);}
function need(array $roles):void{if(!in_array(role(),$roles,true))throw new RuntimeException('Access denied.',403);}
function operational():void{need(['CaseWorker','Supervisor','Admin']);}
function currentUser():?array{if(!uid())return null;$u=q('SELECT * FROM users WHERE user_id=? AND active=1',[uid()])->fetch();if(!$u||(int)($_SESSION['version']??-1)!==(int)$u['session_version']||time()-($_SESSION['last']??0)>1800){$_SESSION=[];return null;}$_SESSION['last']=time();$_SESSION['role']=$u['role'];$_SESSION['username']=$u['username'];return $u;}
function scope(string $alias='c'):array{return role()==='CaseWorker'?["$alias.assigned_worker_id=?",[uid()]]:['1=1',[]];}
function caseRow(int $id,bool $lock=false):array{operational();[$where,$a]=scope();$c=q("SELECT c.*,b.first_name,b.last_name FROM cases c JOIN beneficiaries b ON b.beneficiary_id=c.beneficiary_id WHERE c.case_id=? AND $where".($lock?' FOR UPDATE':''),[$id,...$a])->fetch();if(!$c)throw new RuntimeException('Case unavailable.',404);return $c;}
function benefWhere(string $b='b'):array{return role()==='CaseWorker'?["($b.registered_by=? OR EXISTS(SELECT 1 FROM cases c WHERE c.beneficiary_id=$b.beneficiary_id AND c.assigned_worker_id=?))",[uid(),uid()]]:['1=1',[]];}
function benefRow(int $id):array{operational();[$w,$a]=benefWhere();$r=q("SELECT b.* FROM beneficiaries b WHERE b.beneficiary_id=? AND $w",[$id,...$a])->fetch();if(!$r)throw new RuntimeException('Beneficiary unavailable.',404);return $r;}
function required(string $k,int $max=5000):string{$v=trim((string)($_POST[$k]??''));if($v===''||mb_strlen($v)>$max)throw new RuntimeException('Enter a valid '.str_replace('_',' ',$k).'.');return $v;}
function option(string $k,array $choices):string{$v=required($k);if(!in_array($v,$choices,true))throw new RuntimeException('Invalid '.$k.'.');return $v;}
function day(string $k,bool $optional=false):?string{$v=trim((string)($_POST[$k]??''));if($optional&&$v==='')return null;$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);if(!$d||$d->format('Y-m-d')!==$v)throw new RuntimeException('Enter a valid '.str_replace('_',' ',$k).'.');return $v;}
function passwordInput():string{$p=(string)($_POST['password']??'');if(strlen($p)<12||strlen($p)>72)throw new RuntimeException('Use a password between 12 and 72 bytes.');return $p;}
function go(string $url,string $message=''):void{if($message)$_SESSION['message']=$message;header('Location: '.$url);exit;}
function event(int $id,string $kind,string $details):void{q('INSERT INTO case_events(case_id,kind,details,created_by) VALUES(?,?,?,?)',[$id,$kind,$details,uid()]);}
function writableCase(int $id):array{$c=caseRow($id,true);if($c['case_status']==='Closed')throw new RuntimeException('Closed case records cannot be changed.');return $c;}
function pending(int $id):int{return (int)q("SELECT (SELECT COUNT(*) FROM referrals WHERE case_id=? AND referral_status='Pending')+(SELECT COUNT(*) FROM follow_ups WHERE case_id=? AND status IN ('Scheduled','Missed'))",[$id,$id])->fetchColumn();}
function workers():array{return q("SELECT user_id,username FROM users WHERE role='CaseWorker' AND active=1 ORDER BY username")->fetchAll();}
function worker(int $id):void{if(!q("SELECT user_id FROM users WHERE user_id=? AND active=1 AND role='CaseWorker'",[$id])->fetch())throw new RuntimeException('Choose an active case worker.');}
function lockWrites():void{if((int)q("SELECT GET_LOCK('ngo_v2_write',10)")->fetchColumn()!==1)throw new RuntimeException('The system is busy. Try again shortly.');}
function unlockWrites():void{q("SELECT RELEASE_LOCK('ngo_v2_write')");}
function reportFilter():array{[$w,$a]=scope();foreach(['from'=>'>=','to'=>'<='] as $k=>$op){$v=trim((string)($_GET[$k]??''));if($v){$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);if(!$d||$d->format('Y-m-d')!==$v)throw new RuntimeException('Invalid report date.');$w.=" AND c.date_opened $op ?";$a[]=$v;}}if(!empty($_GET['from'])&&!empty($_GET['to'])&&$_GET['from']>$_GET['to'])throw new RuntimeException('Start date must precede end date.');foreach(['programme'=>'case_type','worker'=>'assigned_worker_id','status'=>'case_status'] as $k=>$col){if(($_GET[$k]??'')!==''){$w.=" AND c.$col=?";$a[]=$_GET[$k];}}return [$w,$a];}
