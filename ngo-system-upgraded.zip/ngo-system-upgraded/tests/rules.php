<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/../app/core.php';
$_SESSION['user_id']=123;$_SESSION['role']='CaseWorker';
if(scope()!==['c.assigned_worker_id=?',[123]])throw new RuntimeException('Worker scope failed');
try{need(['Supervisor']);throw new LogicException('Role guard failed');}catch(RuntimeException $e){if($e->getCode()!==403)throw $e;}
if(esc('<script>')!=='&lt;script&gt;')throw new RuntimeException('Escaping failed');
$_POST=['test_date'=>'2026-02-30'];try{day('test_date');throw new LogicException('Date validation failed');}catch(RuntimeException $e){}
echo "Permission scope, role guard, escaping and date checks passed.\n";
