<?php
$pdo=new PDO('mysql:host=127.0.0.1;port=3317','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
if($pdo->query("SHOW DATABASES LIKE 'ngo_features_test'")->fetchColumn())exit('Test database exists; do not overwrite.');
$sql=file_get_contents(__DIR__.'/../Database/schema.sql');$pdo->exec(str_replace('ngo_system','ngo_features_test',$sql));
$s=$pdo->prepare('INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)');foreach(['admin'=>'Admin','super'=>'Supervisor','worker1'=>'CaseWorker','worker2'=>'CaseWorker','manager'=>'Management'] as $name=>$role)$s->execute([$name,$name.'@example.test',password_hash('Testing-Portal-2026!',PASSWORD_DEFAULT),$role]);
echo 'Isolated test database created.';
