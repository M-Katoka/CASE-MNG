import urllib.request as U,urllib.parse as P,http.cookiejar,re,json,io,zipfile
from pathlib import Path
from pypdf import PdfReader
from openpyxl import load_workbook
BASE='http://127.0.0.1:8082/'
checks=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label);print('PASS '+label,flush=True)
class Client:
 def __init__(self):self.o=U.build_opener(U.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def req(self,path,data=None,headers={}):
  try:r=self.o.open(U.Request(BASE+path,data,headers),timeout=20)
  except U.HTTPError as e:r=e
  b=r.read();return r.code,b,r.geturl(),r.headers
 def get(self,path):return self.req(path)[1].decode()
 def post(self,path,fields,source=None):
  s=self.get(source or path);m=re.search(r'name="csrf" value="([^"]+)"',s)
  return self.req(path,P.urlencode(dict(csrf=m.group(1),**fields)).encode())
 def login(self,name,pw='Testing-Portal-2026!'):
  r=self.post('login.php',dict(username=name,password=pw));check('dashboard.php' in r[2],'login '+name);return self
admin=Client().login('admin');sup=Client().login('super');w1=Client().login('worker1');w2=Client().login('worker2');mgr=Client().login('manager');guest=Client()
check('users_admin' not in guest.req('register.php')[2],'public registration cannot create administrator')
check('Set a new password' in guest.get('reset_password.php'),'reset GET does not reset admin password')
check(w1.req('cases.php',P.urlencode(dict(action='create_case')).encode())[0]==403,'CSRF rejection')
bfields=dict(action='beneficiary',first_name='Test Alpha',last_name='Client',date_of_birth='1990-01-02',sex='Female',location='District A',contact_info='11111',registration_date='2026-11-03')
r=w1.post('beneficiaries.php',bfields);check(r[0]==200 and 'Test Alpha' in r[1].decode(),'beneficiary registration')
r=w1.post('beneficiaries.php',bfields);check('Duplicate warning' in r[1].decode(),'exact duplicate rejected')
f=dict(bfields,first_name='Test Beta',contact_info='22222');w2.post('beneficiaries.php',f)
check('Test Beta' not in w1.get('beneficiaries.php'),'beneficiary list scoped')
check(w1.req('beneficiaries.php?edit=2')[0] in [200,404] and 'Test Beta' not in w1.get('beneficiaries.php?edit=2'),'beneficiary direct access blocked')
cfields=dict(action='create_case',beneficiary_id=1,case_type='Education',priority='High',date_opened='2026-11-03')
r=w1.post('cases.php',cfields);check('case_details.php?id=1' in r[2],'case creation')
w2.post('cases.php',dict(cfields,beneficiary_id=2,case_type='Health'))
check(w1.req('case_details.php?id=2')[0]==404,'case direct URL isolation')
check('Test Beta' not in w1.get('cases.php'),'case list isolation')
r=w1.post('case_details.php?id=1',dict(action='followup',case_id=2,next_follow_up_date='2026-11-01',notes='forged'));check(r[0]==404,'forged case POST blocked')
for fields in [dict(action='assessment',assessment_date='2026-11-03',risk_level='High',identified_needs='Education need',observations='Observe',recommendations='Support'),dict(action='intervention',service_type='Counselling',service_provider='Demo NGO',intervention_date='2026-11-03',description='Service given',outcome='Completed session'),dict(action='referral',referred_to_organization='Demo partner',service_required='Learning support',referral_date='2026-11-01',due_date='2026-11-02'),dict(action='followup',next_follow_up_date='2026-11-02',notes='Call the partner')]:
 r=w1.post('case_details.php?id=1',dict(fields,case_id=1));check(r[0]==200,'create '+fields['action'])
s=w1.get('case_details.php?id=1');check(all(x in s for x in ['Education need','Counselling','Demo partner','Call the partner']),'unified timeline contains all four activities')
check('Overdue' in w1.get('follow_ups.php') and 'Overdue' in w1.get('referrals.php'),'overdue reminders')
check('Demo partner' not in w2.get('referrals.php'),'referral list isolation')
r=w1.post('case_details.php?id=1',dict(action='request_close',case_id=1,closure_outcome='Achieved'));check('Resolve pending' in r[1].decode(),'closure blocked with pending work')
# Upload an actual PDF using multipart.
def upload(client,content,name='assessment.pdf'):
 token=re.search(r'name="csrf" value="([^"]+)"',client.get('case_details.php?id=1')).group(1);boundary='----NGOtestboundary';body=b''
 for k,v in dict(csrf=token,action='upload',case_id='1',description='Assessment attachment').items():body+=f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
 body+=f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+content+f'\r\n--{boundary}--\r\n'.encode()
 return client.req('case_details.php?id=1',body,{'Content-Type':'multipart/form-data; boundary='+boundary})
pdf=Path(__file__).with_name('fixture.pdf').read_bytes();r=upload(w1,pdf);check(r[0]==200 and 'assessment.pdf' in r[1].decode(),'PDF upload')
check(w1.req('documents.php?id=1')[1]==pdf,'authorised attachment download')
check(w2.req('documents.php?id=1')[0]==404,'attachment access isolation')
check('Only PDF' in upload(w1,b'<?php echo 1;?>','bad.php')[1].decode(),'executable upload rejected')
for fields in [dict(action='resolve_referral',referral_id=1,referral_status='Completed',completion_info='Service received'),dict(action='resolve_followup',follow_up_id=1,outcome='Confirmed support')]:
 r=w1.post('case_details.php?id=1',dict(fields,case_id=1));check(r[0]==200,fields['action'])
r=w1.post('case_details.php?id=1',dict(action='request_close',case_id=1,closure_outcome='Needs met'));check('Awaiting supervisor' in r[1].decode(),'closure request recorded')
r=admin.post('case_details.php?id=1',dict(action='review_close',case_id=1,decision='Approve',closure_review='Checked'));check(r[0]==403,'administrator cannot bypass supervisor review')
r=sup.post('case_details.php?id=1',dict(action='review_close',case_id=1,decision='Approve',closure_review='Reviewed support evidence'));check('Closed' in r[1].decode(),'supervisor approval closes case')
r=w1.post('case_details.php?id=1',dict(action='followup',case_id=1,next_follow_up_date='2026-11-05',notes='late'));check('Closed case records cannot be changed' in r[1].decode(),'closed case is immutable')
check(mgr.req('case_details.php?id=1')[0]==403,'management cannot access case')
r=w1.req('export.php?format=xlsx&programme=Education&from=2026-11-01&to=2026-11-04');wb=load_workbook(io.BytesIO(r[1]));values=list(wb.active.values);check(len(values)==2 and values[1][2]=='Education','filtered real XLSX export');check('Test Beta' not in str(values),'export does not leak other worker')
r=w1.req('export.php?format=pdf');reader=PdfReader(io.BytesIO(r[1]));text=''.join(x.extract_text() for x in reader.pages);check('Test Alpha' in text and 'Test Beta' not in text,'PDF export scoped');Path('work/test-export.pdf').write_bytes(r[1])
r=mgr.req('export.php?format=xlsx');wb=load_workbook(io.BytesIO(r[1]));check('Beneficiary' not in str(list(wb.active.values)) and 'Test Alpha' not in str(list(wb.active.values)),'management export is aggregate only')
# Password recovery request, admin verification, expiry and reuse.
r=guest.post('forgot_password.php',dict(username='worker2'));check('If the account exists' in r[1].decode(),'generic recovery response')
check('worker2' in admin.get('users_admin.php'),'recovery request visible to admin')
r=admin.post('users_admin.php',dict(action='issue_reset',user_id=5,admin_password='Testing-Portal-2026!',verified_identity='1'));link=re.search(r'<code>(reset_password.php\?token=[a-f0-9]+)</code>',r[1].decode()).group(1);raw=link.split('=')[1]
r=guest.post(link,dict(token=raw,password='New-Worker2-Password!',confirm_password='New-Worker2-Password!'));check('Password updated' in r[1].decode(),'one-time password recovery')
check('login.php' in w2.req('cases.php')[2],'recovery invalidates old sessions')
r=guest.post(link,dict(token=raw,password='Another-Password-2026!',confirm_password='Another-Password-2026!'));check('invalid or expired' in r[1].decode(),'recovery link cannot be reused')
w2=Client().login('worker2','New-Worker2-Password!')
check('closure Approve' in admin.get('audit.php'),'audit records closure')
# Real snapshot + restore with attached document.
r=admin.post('backups.php',dict(action='backup'));check('Backup created' in r[1].decode(),'complete backup created');name=re.search(r'download=(ngo-[^"&]+\.zip)',r[1].decode()).group(1)
b=admin.req('backups.php?download='+name)[1];z=zipfile.ZipFile(io.BytesIO(b));manifest=json.loads(z.read('manifest.json'));check(len(manifest['tables']['cases'])==2 and len(manifest['tables']['documents'])==1,'backup contains data and attachment metadata');check(any(n.startswith('documents/') for n in z.namelist()),'backup includes document bytes')
check(w1.req('backups.php')[0]==403,'worker cannot access backup')
admin.post('beneficiaries.php',dict(bfields,first_name='AfterSnapshot',contact_info='33333'))
r=admin.post('backups.php',dict(action='restore',backup_name=name,admin_password='Testing-Portal-2026!',confirmation='RESTORE'));check('login.php' in r[2],'restore completes and logs users out')
admin=Client().login('admin');check('AfterSnapshot' not in admin.get('beneficiaries.php'),'restore recovers snapshot records');check(admin.req('documents.php?id=1')[1]==pdf,'restore recovers document bytes');check('restore completed' in admin.get('audit.php'),'restore audited')
Path('work/feature-test-results.json').write_text(json.dumps(checks,indent=2));print('TOTAL',len(checks))
