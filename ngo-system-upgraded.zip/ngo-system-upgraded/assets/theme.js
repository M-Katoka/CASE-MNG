(() => {
    'use strict';

    const root = document.documentElement;

    function getInitialTheme() {
        try {
            const saved = localStorage.getItem('ngo-theme');

            if (saved === 'light' || saved === 'dark') {
                return saved;
            }
        } catch (error) {
            // Continue without persistent storage.
        }

        return window.matchMedia('(prefers-color-scheme: dark)').matches
            ? 'dark'
            : 'light';
    }

    function updateButtons() {
        const isDark = root.getAttribute('data-bs-theme') === 'dark';

        document.querySelectorAll('[data-app-theme-toggle]').forEach(button => {
            const label = isDark ? 'Switch to light theme' : 'Switch to dark theme';
            const icon = button.querySelector('[data-theme-icon]');
            const text = button.querySelector('[data-theme-label]');

            button.setAttribute('aria-label', label);
            button.title = label;

            if (icon) {
                icon.className = isDark
                    ? 'bi bi-sun'
                    : 'bi bi-moon-stars';
            }

            if (text) {
                text.textContent = isDark ? 'Light theme' : 'Dark theme';
            }
        });
    }

    function applyTheme(theme, persist = false) {
        root.setAttribute('data-bs-theme', theme);

        if (persist) {
            try {
                localStorage.setItem('ngo-theme', theme);
            } catch (error) {
                // Theme switching still works without storage.
            }
        }

        updateButtons();
    }

    applyTheme(getInitialTheme());

    document.addEventListener('DOMContentLoaded', updateButtons);

    document.addEventListener('click', event => {
        const button = event.target.closest('[data-app-theme-toggle]');

        if (!button) {
            return;
        }

        const nextTheme = root.getAttribute('data-bs-theme') === 'dark'
            ? 'light'
            : 'dark';

        applyTheme(nextTheme, true);
    });

    window.addEventListener('storage', event => {
        if (event.key === 'ngo-theme') {
            applyTheme(getInitialTheme());
        }
    });
})();